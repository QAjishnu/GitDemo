package com.intBanking.TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.intBanking.pageObjects.AddCustomer;
import com.intBanking.pageObjects.LoginPage;

public class TC_AddCustomer_002 extends BaseClass {
	
	@Test
	public void addnewcustomer() throws InterruptedException
	{
		LoginPage lp=new LoginPage(driver);
		lp.setusername(username);
		lp.setpassword(password);
		lp.Clicksubmit();
		
		Thread.sleep(5000);
		
		AddCustomer adc = new AddCustomer(driver);
		adc.clickAddnewCustomer();
		adc.custname("Pavan");
		adc.custgeder("male");
		adc.custDOB("10", "15", "1985");
		adc.custaddress("India");
		adc.custcity("NOida");
		adc.custstate("UP");
		adc.custpinno(201301);
		adc.custtelephone(1234567);
		adc.cemail("ab12.3@gmail.com");
		adc.custpwd("12qwe43r");
		adc.submit();
		
		Thread.sleep(3000);
		
		boolean res =driver.getPageSource().contains("Customer Registered Successfully!!!");
		
		if(res==true)
		{
			Assert.assertTrue(true);
		}
		else {
			
		}
		
	}

	
	

}
