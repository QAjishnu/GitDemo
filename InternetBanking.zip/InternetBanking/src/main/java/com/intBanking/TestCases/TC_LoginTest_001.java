package com.intBanking.TestCases;
//import static org.testng.Assert.assertTrue;
//import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.intBanking.pageObjects.LoginPage;

public class TC_LoginTest_001 extends BaseClass{
	
	@Test
	public void LoginTest()
	{
		driver.get(baseURl);
		//Logger.info("URL is opened");
		
		LoginPage lp = new LoginPage(driver);
		lp.setusername(username);
		//Logger.info("Entered username");

		lp.setpassword(password);
		//Logger.info("URL password");

		lp.Clicksubmit();
		String tit =driver.getTitle();
		Assert.assertTrue(tit.equalsIgnoreCase("Guru99 Bank Manager HomePage"), "ValidationOfPageTitle");
		
		/*if(driver.getTitle().equals("Guru99 Bank Manager Homepage"))
		{
			Assert.assertTrue(false);
		}
		else
		{
			Assert.assertTrue(true);
		}	*/
	}
}
