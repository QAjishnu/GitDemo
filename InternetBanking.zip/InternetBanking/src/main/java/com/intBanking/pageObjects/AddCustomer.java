package com.intBanking.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AddCustomer {
	WebDriver driver;	
	public AddCustomer(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	@FindBy(how=How.XPATH, using="//a[contains(text(),'New Customer')]")
	WebElement lnkAddnewCustomer;
	//@FindBy(xpath="//a[contains(text(),'New Customer')]")
	//WebElement lnkAddnewCustomer;
	@FindBy(how=How.NAME, using="name")
	WebElement txtcustomername;
	@FindBy(how=How.NAME, using="rad1")
	WebElement rdGender;	
	@FindBy(how=How.ID_OR_NAME, using="dob")
	WebElement txtdob;	
	@FindBy(how=How.NAME, using="adr")
	WebElement txtaddress;	
	@FindBy(how=How.NAME, using="city")
	WebElement txtcity;	
	@FindBy(how=How.NAME, using="state")
	WebElement txtstate;	
	@FindBy(how=How.NAME, using="pinno")
	WebElement txtpin;	
	@FindBy(how=How.NAME, using="telephoneno")
	WebElement txttelephone;	
	@FindBy(how=How.NAME, using="emailid")
	WebElement txtemail;		
	@FindBy(how=How.NAME, using="password")
	WebElement txtpassword;
	@FindBy(how=How.NAME, using="sub")
	WebElement btnsubmit;	

//now for every elemnt write an action method.

public void clickAddnewCustomer()
{
	lnkAddnewCustomer.click();
}
public void custname(String cname)
{
	txtcustomername.sendKeys(cname);
}
public void custgeder(String cgender)
{
	rdGender.click();
}
public void custDOB(String mm, String dd, String yy)
{
	txtdob.sendKeys(mm);
	txtdob.sendKeys(dd);
	txtdob.sendKeys(yy);
}
public void custaddress(String caddress)
{
	txtaddress.sendKeys(caddress);
}
public void custcity(String ccity)
{
	txtcity.sendKeys(ccity);
}
public void custstate(String cstate)
{
	txtstate.sendKeys(cstate);
}
public void custpinno(int pin)
{
	txtpin.sendKeys(String.valueOf(pin));
}
public void custtelephone(int ctele)
{
	txttelephone.sendKeys(String.valueOf(ctele));
}
public void cemail(String cemail)
{
	txtemail.sendKeys(cemail);
}
public void custpwd(String password)
{
	txtpassword.sendKeys(password);
}
public void submit()
{
	btnsubmit.click();
}
}
