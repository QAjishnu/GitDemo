package com.intBanking.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	//create a webdriver refrence variable
	WebDriver driver;
	
	//Declare a constructor and passWebdriver refrence as  an input parameter
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;	
	//call initelemts()  method by using pagefactory refernce and pass driver and this as parameters
	PageFactory.initElements(driver, this);
	}
	 
	@FindBy(name="uid")
	WebElement txtUsername;
	
	@FindBy(name="password")
	WebElement txtPassword;
	
	@FindBy(name="btnLogin")
	WebElement btnLogin;
	
	
	public void setusername(String uname)
	{
		txtUsername.sendKeys(uname);
	}
	
	public void setpassword(String password)
	{
		txtPassword.sendKeys(password);
	}

	public void Clicksubmit()
	{
		btnLogin.click();
	}
	
	
}
