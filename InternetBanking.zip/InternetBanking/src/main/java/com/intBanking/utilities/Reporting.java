package com.intBanking.utilities;

import org.testng.TestListenerAdapter;

public class Reporting extends TestListenerAdapter{

}
